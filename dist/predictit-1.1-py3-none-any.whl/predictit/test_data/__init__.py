"""Module with test data that can be use as data for development of framework, but aslo can be changed by user
and then used for compare_models function to find the best suited models for user defined data. Data than can be pickled to faster loading.

"""

from . import generate_test_data
from . import pickle_test_data